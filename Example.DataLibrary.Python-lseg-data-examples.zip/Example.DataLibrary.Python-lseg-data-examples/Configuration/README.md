# LSEG Data Library for Python

## Summary  

This repository provides a series examples that demonstrate how to programmatically access content residing within the **London Stock Exchange Group Data Platform (LDP)** using a single, ease of use software library called the **LSEG Data Library for Python**.
This library is supported and maintained by LSEG.

### **Configuration**

This Configuration folder contains the configuration file - ***lseg-data.config.json*** - for the LSEG Data Library for Python. Before running any of the tutorials, you must modify this file depending on the access channel and connection parameters that you will use to connect to the LSEG Data Platform.

The accompanying tutorials should be used in conjunction with the **Tutorials** and **Documentation** available on the [LSEG Developer Portal](https://developers.refinitiv.com/en)
